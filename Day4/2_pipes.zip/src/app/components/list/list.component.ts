import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'list',
  templateUrl: './list.component.html',
  styles: [
  ]
})
export class ListComponent implements OnInit {
  @Input() personList: Array<string>;
  selected: string;
  by: string;

  constructor() {
    this.personList = [];
    this.selected = "";
    this.by = "";
  }

  ngOnInit(): void {
  }

  select(person_name: string, e: Event) {
    this.selected = person_name;
    e.preventDefault();
  }
}
