import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'clock',
  templateUrl: './clock.component.html',
  styleUrls: ['./clock.component.css']
})
export class ClockComponent implements OnInit {
  currentTime?: string;

  constructor() { }

  ngOnInit(): void {
    setInterval(() => {
      this.currentTime = this.calculateTime();
    }, 1000);
  }

  calculateTime() {
    var date = new Date();

    var h: number | string = date.getHours();
    var m: number | string = date.getMinutes();
    var s: number | string = date.getSeconds();
    var amOrpm = "AM";

    if (h == 0) {
      h = 12;
    }

    if (h > 12) {
      h = h - 12;
      amOrpm = "PM";
    }

    h = (h < 10) ? "0" + h : h;
    m = (m < 10) ? "0" + m : m;
    s = (s < 10) ? "0" + s : s;

    var time = `${h}:${m}:${s} ${amOrpm}`;
    return time;
  }
}
