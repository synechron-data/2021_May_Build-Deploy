import { Component, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { CounterComponent } from '../counter/counter.component';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html'
})
export class RootComponent {
  @ViewChild("c1")
  counter1?: CounterComponent;

  @ViewChild("c2")
  counter2?: CounterComponent;

  @ViewChildren(CounterComponent)
  counters?: QueryList<CounterComponent>;

  pList: Array<string>;
  message: string;

  constructor() {
    this.pList = ["Manish", "Abhijeet", "Abhishek", "Ramakant", "Subodh"];
    this.message = "";
  }

  updateMessage(flag: boolean) {
    if (flag)
      this.message = "Max Click Reached, please use the reset button to restart";
    else
      this.message = "";
  }

  p2_reset(counter: CounterComponent) {
    counter.reset();
  }

  p3_reset() {
    this.counter1?.reset();
    this.counter2?.reset();
  }

  reset_all() {
    if (this.counters) {
      for (const c of this.counters) {
        c.reset();
      }
    }
  }
}
