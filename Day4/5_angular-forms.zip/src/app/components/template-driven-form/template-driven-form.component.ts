import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'template-drive-form',
  templateUrl: './template-driven-form.component.html'
})
export class TemplateDrivenFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  logForm(frm: any) {
    // Code to send this data to a HTTP API
    console.log(frm.value);
  }
}
