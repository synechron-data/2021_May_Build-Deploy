import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomValidator } from 'src/app/untilities/CustomValidator';

@Component({
  selector: 'validation-form',
  templateUrl: './validation-form.component.html',
  styles: [
  ]
})
export class ValidationFormComponent implements OnInit {
  regForm: FormGroup;

  countries = [
    { 'id': "", 'name': 'Select Country' },
    { 'id': 1, 'name': 'India' },
    { 'id': 2, 'name': 'USA' },
    { 'id': 3, 'name': 'UK' }
  ];

  minAge = 18;
  maxAge = 60;

  constructor(private frmBuilder: FormBuilder) {
    this.regForm = this.frmBuilder.group({
      firstname: ["", Validators.required],
      lastname: ["", Validators.compose([
        Validators.required,
        Validators.maxLength(6),
        Validators.minLength(2)
      ])],
      gender: ["", Validators.required],
      age: [0, [
        Validators.required,
        // CustomValidator.ageRange
        CustomValidator.ageRange(this.minAge, this.maxAge)
      ]],
      address: this.frmBuilder.group({
        country: ["", Validators.required],
        city: ["", Validators.required],
        zip: [0, Validators.required],
      }),
      acceptTerms: [false, Validators.requiredTrue]
    });
  }

  get frm() { return this.regForm.controls; }
  get address() { return (<FormGroup>this.regForm.controls.address).controls; }

  ngOnInit(): void {
  }

  logForm() {
    if (this.regForm.valid)
      console.log(this.regForm.value);
    else {
      this.regForm.markAllAsTouched();
      console.error("Invalid Form Data");
    }
  }

  reset() {
    this.regForm.reset();
  }
}
