import { Component, OnInit } from '@angular/core';
import { interval, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
  selector: 'clock',
  templateUrl: './clock.component.html',
  styleUrls: ['./clock.component.css']
})
export class ClockComponent implements OnInit {
  currentTime?: Observable<Date>;

  constructor() { }

  ngOnInit(): void {
    this.currentTime = interval(1000).pipe(map(o => new Date()));
  }
}
