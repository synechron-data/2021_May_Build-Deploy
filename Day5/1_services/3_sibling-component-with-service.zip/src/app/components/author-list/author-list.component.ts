import { Component, OnInit } from '@angular/core';
import { Author } from 'src/app/models/author.interface';
import { AuthorService } from 'src/app/services/author.service';

@Component({
  selector: 'author-list',
  templateUrl: './author-list.component.html',
  styleUrls: ['./author-list.component.css']
})
export class AuthorListComponent implements OnInit {
  list?: Array<Author>;
  selectedAuthor?: Author;

  constructor(private authorService: AuthorService) { }

  ngOnInit() {
    this.list = this.authorService.Authors;
  }

  selectAuthor(a: Author) {
    this.authorService.SelectedAuthor = a;
    this.selectedAuthor = this.authorService.SelectedAuthor;
  }

  isSelected(a: Author) {
    return this.selectedAuthor === a;
  }
}
