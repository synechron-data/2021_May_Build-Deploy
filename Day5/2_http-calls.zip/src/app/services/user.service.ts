import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, throwError } from "rxjs";
import { catchError, delay, retry } from "rxjs/operators";
import { User } from "../models/user.model";

@Injectable()
export class UserService {
    private url: string;

    constructor(private httpClient: HttpClient) {
        this.url = "https://jsonplaceholder.typicode.com/users";
    }

    getAllUsers() {
        return this.httpClient.get<Array<User>>(this.url).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError<Array<User>>("getAllUsers", []))
        );
    }

    private _handleError<T>(operation = "operation", result?: T) {
        return (err: HttpErrorResponse): Observable<T> => {
            // Error Logging
            console.error(`${operation} failed: ${err.message}`);
            return throwError('Connection Error, please try again later...');
        }
    }
}