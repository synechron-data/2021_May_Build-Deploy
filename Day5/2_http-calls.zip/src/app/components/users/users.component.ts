import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { User } from 'src/app/models/user.model';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'users',
  templateUrl: './users.component.html',
  providers: [UserService]
})
export class UsersComponent implements OnInit, OnDestroy {
  users?: Array<User>;
  flag: boolean;
  message?: string;
  get_sub?: Subscription;

  constructor(private userService: UserService) {
    this.flag = false;
  }

  ngOnInit(): void {
    this.get_sub = this.userService.getAllUsers().subscribe(resData => {
      this.users = [...resData];
      this.flag = true;
    }, (err: string) => {
      this.message = err;
      this.flag = true;
    });
  }

  ngOnDestroy(): void {
    this.get_sub?.unsubscribe();
  }
}
