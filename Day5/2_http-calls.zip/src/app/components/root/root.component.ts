// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { HttpClient, HttpErrorResponse } from '@angular/common/http';
// import { Post } from 'src/app/models/post.model';
// import { Subscription } from 'rxjs';
// import { delay } from 'rxjs/operators';

// @Component({
//     selector: 'app-root',
//     templateUrl: 'root.component.html',
//     styleUrls: ['./root.component.css']
// })

// export class RootComponent implements OnInit, OnDestroy {
//     url: string;
//     message: string;
//     flag: boolean;
//     posts?: Array<Post>;
//     get_sub?: Subscription;

//     constructor(private httpClient: HttpClient) {
//         this.url = "https://jsonplaceholder.typicode.com/posts";
//         this.message = "Loading Data, Please wait...";
//         this.flag = false;
//     }

//     ngOnInit() {
//         this.get_sub = this.httpClient.get<Array<Post>>(this.url).pipe(delay(5000)).subscribe(resData => {
//             this.posts = [...resData];
//             this.message = "";
//             this.flag = true;
//         }, (err: HttpErrorResponse) => {
//             this.message = err.message;
//             this.flag = true;
//         });
//     }

//     ngOnDestroy(): void {
//         this.get_sub?.unsubscribe();
//     }
// }

// -------------------------------------------------------------------------------------------

// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { HttpErrorResponse } from '@angular/common/http';
// import { Post } from 'src/app/models/post.model';
// import { Subscription } from 'rxjs';
// import { delay } from 'rxjs/operators';
// import { PostService } from 'src/app/services/post.service';

// @Component({
//     selector: 'app-root',
//     templateUrl: 'root.component.html',
//     styleUrls: ['./root.component.css'],
//     providers: [PostService]
// })

// export class RootComponent implements OnInit, OnDestroy {
//     message: string;
//     flag: boolean;
//     posts?: Array<Post>;
//     get_sub?: Subscription;

//     constructor(private postService: PostService) {
//         this.message = "Loading Data, Please wait...";
//         this.flag = false;
//     }

//     ngOnInit() {
//         this.get_sub = this.postService.getAllPosts().pipe(delay(5000)).subscribe(resData => {
//             this.posts = [...resData];
//             this.message = "";
//             this.flag = true;
//         }, (err: HttpErrorResponse) => {
//             this.message = err.message;
//             this.flag = true;
//         });
//     }

//     ngOnDestroy(): void {
//         this.get_sub?.unsubscribe();
//     }
// }

// -------------------------------------------------------------------------------------------

import { Component, OnDestroy, OnInit } from '@angular/core';
import { Post } from 'src/app/models/post.model';
import { Subscription } from 'rxjs';
import { PostService } from 'src/app/services/post.service';

@Component({
    selector: 'app-root',
    templateUrl: 'root.component.html',
    styleUrls: ['./root.component.css'],
    providers: [PostService]
})

export class RootComponent implements OnInit, OnDestroy {
    message: string;
    flag: boolean;
    posts?: Array<Post>;
    get_sub?: Subscription;
    ins_sub?: Subscription;
    del_sub?: Subscription;

    constructor(private postService: PostService) {
        this.message = "Loading Data, Please wait...";
        this.flag = false;
    }

    // Submit Form Method
    insertPost() {
        this.flag = false;
        // newPost is the data enetered on the Form
        let newPost: Post = {
            userId: 1,
            id: 0,
            title: "Test",
            body: "Test"
        };

        this.ins_sub = this.postService.insertPost(newPost).subscribe(resData => {
            this.posts?.unshift(resData);
            this.message = "Record Inserted Successfully...";
            this.flag = true;
            setTimeout(() => {
                this.message = "";
            }, 5000);
        }, (err: string) => {
            this.message = err;
            this.flag = true;
        });
    }

    deletePost(id: number, e: Event) {
        this.flag = false;

        e.preventDefault();
        this.del_sub = this.postService.deletePost(id).subscribe(_ => {
            if (this.posts)
                this.posts = [...this.posts.filter(p => p.id !== id)];
            this.message = "Record Deleted Successfully...";
            this.flag = true;
            setTimeout(() => {
                this.message = "";
            }, 5000);
        }, (err: string) => {
            this.message = err;
            this.flag = true;
        });
    }

    ngOnInit() {
        this.get_sub = this.postService.getAllPosts().subscribe(resData => {
            this.posts = [...resData];
            this.message = "";
            this.flag = true;
        }, (err: string) => {
            this.message = err;
            this.flag = true;
        });
    }

    ngOnDestroy(): void {
        this.get_sub?.unsubscribe();
        this.ins_sub?.unsubscribe();
        this.del_sub?.unsubscribe();
    }
}