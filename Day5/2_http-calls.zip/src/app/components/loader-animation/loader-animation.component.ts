import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'loader-animation',
  templateUrl: './loader-animation.component.html',
  styles: [
  ]
})
export class LoaderAnimationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
