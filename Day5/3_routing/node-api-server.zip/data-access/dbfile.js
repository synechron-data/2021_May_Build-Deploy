var fs = require("fs");

module.exports.getAllUsers = function (cb) {
    var obj = require("../dbfile/Users.json");
    cb(obj.usersData);
}