const da = require('../data-access/dbfile');

exports.getUsers = function (req, res, next) {
    da.getAllUsers((result) => {
        res.json({ data: result, message: "Success, Getting Users", success: true });
    });
}

exports.getUser = function (req, res, next) {

}

exports.createUser = function (req, res, next) {

}

exports.updateUser = function (req, res, next) { }

exports.deleteUser = function (req, res, next) { }
// const da = require('../data-access');
// const User = require('../models/user');

// exports.getUsers = function (req, res, next) {
//     da.getAllUsers().then((result) => {
//         res.json({ data: result, message: "Success, Getting Users", success: true });
//     }, (eMsg) => {
//         res.json({ data: [], message: "Error, Getting Users", success: false });
//     });
// }

// exports.getUser = function (req, res, next) {
//     da.getUser(req.params.userid).then((result) => {
//         res.json({ data: result, message: "Success, Getting User", success: true });
//     }, (eMsg) => {
//         res.json({ data: null, message: "Error, Getting User", success: false });
//     });
// }

// exports.createUser = function (req, res, next) {
//     // console.log(req.body);
//     var user = new User(req.body.username, req.body.email);

//     da.insertUser(user).then((result)=>{
//         res.json({ data: result, message: "Success, Inserting User", success: true });
//     }, (eMsg)=>{
//         res.json({ data: user, message: "Error, Inserting User", success: false });
//     })
// }

// exports.updateUser = function (req, res, next) {
//     // console.log(req.body);
//     var user = new User(req.body.username, req.body.email);

//     da.updateUser(req.params.userid, user).then((result)=>{
//         res.json({ data: result, message: "Success, Updating User", success: true });
//     }, (eMsg)=>{
//         res.json({ data: user, message: "Error, Updating User", success: false });
//     })
// }

// exports.deleteUser = function (req, res, next) {
//     da.deleteUser(req.params.userid).then((result) => {
//         res.json({ data: null, message: result, success: true });
//     }, (eMsg) => {
//         res.json({ data: null, message: "Error, Deleting User", success: false });
//     });
// }