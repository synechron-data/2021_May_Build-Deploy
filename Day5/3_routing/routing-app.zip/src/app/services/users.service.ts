import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, delay, retry } from 'rxjs/operators';
import { UserServiceResponse } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  private url: string;

  constructor(private httpClient: HttpClient) {
    this.url = "http://localhost:8000/api/users";
  }

  getAllUsers() {
    return this.httpClient.get<UserServiceResponse>(this.url).pipe(
      delay(3000),
      retry(3),
      catchError(this._handleError<UserServiceResponse>("getAllUsers"))
    );
  }

  private _handleError<T>(operation = "operation", result?: T) {
    return (err: HttpErrorResponse): Observable<T> => {
      // Error Logging
      console.error(`${operation} failed: ${err.message}`);
      return throwError(err.error.message);
    }
  }
}
