import { Component, OnDestroy, OnInit } from '@angular/core';
import { AuthenticatorService } from 'src/app/services/authenticator.service';
import { UsersService } from 'src/app/services/users.service';
declare var $: any;

@Component({
  selector: 'admin',
  templateUrl: './admin.component.html'
})
export class AdminComponent implements OnInit, OnDestroy {
  users?: Array<any>;
  message: string;

  constructor(private userService: UsersService, private authenticatorService: AuthenticatorService) {
    this.message = "Loading Data, please wait...";
  }


  ngOnInit(): void {
    this.userService.getAllUsers().subscribe(resData => {
      this.users = resData.data;
      $('.toast').toast('show');
      this.message = resData.message;
      setTimeout(() => {
        this.message = "";
      }, 5000);
    }, (err: string) => {
      $('.toast').toast('show');
      this.message = err;
    });
  }

  ngOnDestroy(): void {
    this.authenticatorService.logout();
  }
}
