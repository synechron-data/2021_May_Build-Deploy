const HtmlWebpackPlugin = require("html-webpack-plugin");

module.exports = {
    entry: {
        app: './src/usage.ts'
    },

    resolve: {
        extensions: ['.ts', '.js']
    },

    module: {
        rules: [
            {
                test: /\.ts?$/,
                use: 'ts-loader',
                exclude: /node_modules/
            }
        ]
    },

    plugins: [
        new HtmlWebpackPlugin({
            template: './public/index.html',
            filename: './index.html',
            scriptLoading: 'blocking'
        })
    ],

    output: {
        publicPath: 'http://localhost:3000',
        filename: '[name].js'
    },

    devServer: {
        inline: true,
        port: 3000,
        historyApiFallback: true,
        clientLogLevel: 'none',
        stats: 'errors-only',
        open: 'Chrome',
        hot: true
    }
};