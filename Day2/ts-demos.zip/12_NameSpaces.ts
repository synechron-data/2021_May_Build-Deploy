// interface IPoint {
//     getDistance(): number;
// }

// class Point implements IPoint {
//     constructor(private x: number, private y: number) { }

//     getDistance() {
//         return Math.sqrt(this.x * this.x | this.y * this.y);
//     }
// }

// let point: IPoint = new Point(2, 3);
// console.log(point.getDistance());

// Where will be the Point class and point instance load at runtime? - Global Scope
// How do you scope code in JavaScript? - Module Pattern

namespace myApp {
    interface IPoint {
        getDistance(): number;
    }

    class Point implements IPoint {
        constructor(private x: number, private y: number) { }

        getDistance() {
            return Math.sqrt(this.x * this.x | this.y * this.y);
        }
    }

    let point: IPoint = new Point(2, 3);
    console.log(point.getDistance());
}