// class DAL {
//     getCustomers() {
//         try {
//             Code to pull data from DB
//             throw new Error('Exception Thrown!!!');
//         } catch (e) {
//             console.log(e.message);
//         }
//     }
// }

function catchAll<T>(target: T, propertyKey: string, descriptor: PropertyDescriptor) {
    // console.log(descriptor);
    var originalMethod = descriptor.value;

    descriptor.value = function (...args: any[]) {
        try {
            var result = originalMethod.apply(this, args);
            return result;
        } catch (err) {
            console.log(err.message);
        }
    };

    return descriptor;
}

class DAL {
    @catchAll
    getCustomers() {
        // Code to pull data from DB
        throw new Error('Exception Thrown!!!');
    }
}

var dObject = new DAL();
dObject.getCustomers();