import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthenticatorService } from '../authenticator.service';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
  constructor(private authenticatorService: AuthenticatorService) { }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (new RegExp('api/users').test(request.url)) {
      const authReq = request.clone({
        setHeaders: {
          'x-access-token': <string>this.authenticatorService.getToken()
        }
      });

      return next.handle(authReq);
    } else {
      return next.handle(request);
    }
  }
}
