import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, delay, retry } from 'rxjs/operators';
import { Customer } from '../models/customer.model';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  private url: string;

  constructor(private httpClient: HttpClient) {
    this.url = "http://35.225.55.33/api/v1/customers";
  }

  getAllCustomers() {
    return this.httpClient.get<Array<Customer>>(this.url).pipe(
      delay(3000),
      retry(3),
      catchError(this._handleError<Array<Customer>>("getAllCustomers"))
    );
  }

  private _handleError<T>(operation = "operation", result?: T) {
    return (err: HttpErrorResponse): Observable<T> => {
      // Error Logging
      console.error(`${operation} failed: ${err.message}`);
      return throwError(err.error.message);
    }
  }
}
