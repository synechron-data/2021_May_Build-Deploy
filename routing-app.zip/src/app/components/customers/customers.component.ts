import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/models/customer.model';
import { CustomerService } from 'src/app/services/customer.service';

@Component({
  selector: 'customers',
  template: `
    <ul class="list-group mt-5">
      <li class="list-group-item" *ngFor="let c of customers">
          <h2>{{c.id}}</h2>
          <h3>{{c.name}}</h3>
          <h3>{{c.email}}</h3>
      </li>
    </ul>
  `,
  styles: [
  ]
})
export class CustomersComponent implements OnInit {
  customers?: Array<Customer>;
  message: string;

  constructor(private customerService: CustomerService) {
    this.message = "Loading Data, please wait...";
  }

  ngOnInit(): void {
    this.customerService.getAllCustomers().subscribe(data => {
      this.customers = data;
    }, (err: string) => {
      this.message = err;
    })
  }
}
