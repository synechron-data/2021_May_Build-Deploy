// function hi() {
//     console.log("Hello World!");
// }

// // Error : Duplicate function implementation.
// function hi(name: string) {
//     console.log("Hello, ", name);
// }

// hi();
// hi("Synechron");

// ----------------------------------------------------
function hi(): void;
function hi(name: string): void;

function hi(...args: string[]) {
    if (args.length === 0)
        console.log("Hello World");
    else if (args.length === 1)
        console.log("Hello,", args[0]);
    else
        throw new Error("Invalid Number of Arguments");
}

hi();
hi("Synechron");
// hi("Synechron", "Pune");        // Compile Time Error: Expected 0-1 arguments, but got 2.