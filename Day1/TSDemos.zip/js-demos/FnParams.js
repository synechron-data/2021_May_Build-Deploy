function hello(name) {
    console.log("Hello,", name);
}

hello("Manish");
hello();
hello("Abhijeet", "Pune");