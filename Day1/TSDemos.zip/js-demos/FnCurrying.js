// function greetings(message, name){
//     console.log(`${message}, ${name}`);
// }

// greetings("Good Morning", "Manish");
// greetings("Good Morning", "Abhijeet");
// greetings("Good Morning", "Ramakant");


// ---------------------------------- Fn Currying

// function greetings(message) {
//     function greet(name) {
//         console.log(`${message}, ${name}`);
//     }
//     return greet;
// }

function greetings(message) {
    return function (name) {
        console.log(`${message}, ${name}`);
    }
}

var mGreet = greetings("Good Morning");
mGreet("Manish");
mGreet("Abhijeet");
mGreet("Ramakant");