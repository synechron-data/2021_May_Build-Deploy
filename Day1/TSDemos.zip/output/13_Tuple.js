function insert(data) {
}
insert([1, "Manish"]);
