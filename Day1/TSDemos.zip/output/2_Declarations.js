var s = Symbol("Hello");
var p = new Promise(function (resolve, reject) { });
