import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html'
})
export class RootComponent {
  flag: boolean;
  name?: string;
  myStyles: any;

  constructor() {
    this.flag = false;
    this.name = "Synechron";
    this.myStyles = {
      'background-color': 'green',
      'font-size': '20px',
      'color': 'white'
    };
  }
}
