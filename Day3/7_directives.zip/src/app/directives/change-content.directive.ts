import { Directive, ElementRef, OnInit, Renderer2 } from '@angular/core';

@Directive({
  selector: '[change-content]'
})
export class ChangeContentDirective implements OnInit {
  constructor(private element: ElementRef<HTMLElement>, private renderer: Renderer2) { }

  ngOnInit(): void {
    // console.log(this.element.nativeElement);
    this.element.nativeElement.innerHTML = "Content and Border added by Custom Directive";
    this.renderer.setStyle(this.element.nativeElement, "border", "2px solid red");
  }
}
