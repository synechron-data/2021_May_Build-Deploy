import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scomp',
  templateUrl: './scomp.component.html',
  styles: [
  ]
})
export class ScompComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
